--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE nftfr_ingsw;
--
-- Name: nftfr_ingsw; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE nftfr_ingsw WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United Kingdom.1252';


ALTER DATABASE nftfr_ingsw OWNER TO postgres;

\connect nftfr_ingsw

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: nft; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nft (
    id character varying(64) NOT NULL,
    author character varying(16),
    owner character varying(16) NOT NULL,
    caption character varying(512) NOT NULL,
    title character varying(128) NOT NULL,
    value double precision DEFAULT 0 NOT NULL,
    tags character varying(512)
);


ALTER TABLE public.nft OWNER TO postgres;

--
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_methods (
    address character varying(64) NOT NULL,
    username character varying(16) NOT NULL,
    type integer NOT NULL,
    balance double precision DEFAULT 50000 NOT NULL
);


ALTER TABLE public.payment_methods OWNER TO postgres;

--
-- Name: reported; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reported (
    nft_id character varying(64) NOT NULL,
    counter integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.reported OWNER TO postgres;

--
-- Name: sale; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sale (
    nft_id character varying(64) NOT NULL,
    seller_address character varying(64) NOT NULL,
    price double precision NOT NULL,
    creation_date timestamp without time zone NOT NULL,
    end_time timestamp without time zone,
    offer_maker character varying(16),
    buyer_address character varying(64)
);


ALTER TABLE public.sale OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    username character varying(16) NOT NULL,
    name character varying(20) NOT NULL,
    surname character varying(20) NOT NULL,
    encrypted_pw character varying(80) NOT NULL,
    rank integer DEFAULT 0 NOT NULL,
    admin boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: nft; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nft (id, author, owner, caption, title, value, tags) FROM stdin;
\.
COPY public.nft (id, author, owner, caption, title, value, tags) FROM '$$PATH$$/4870.dat';

--
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_methods (address, username, type, balance) FROM stdin;
\.
COPY public.payment_methods (address, username, type, balance) FROM '$$PATH$$/4871.dat';

--
-- Data for Name: reported; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reported (nft_id, counter) FROM stdin;
\.
COPY public.reported (nft_id, counter) FROM '$$PATH$$/4873.dat';

--
-- Data for Name: sale; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sale (nft_id, seller_address, price, creation_date, end_time, offer_maker, buyer_address) FROM stdin;
\.
COPY public.sale (nft_id, seller_address, price, creation_date, end_time, offer_maker, buyer_address) FROM '$$PATH$$/4872.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (username, name, surname, encrypted_pw, rank, admin) FROM stdin;
\.
COPY public.users (username, name, surname, encrypted_pw, rank, admin) FROM '$$PATH$$/4869.dat';

--
-- Name: nft nft_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nft
    ADD CONSTRAINT nft_pkey PRIMARY KEY (id);


--
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (address);


--
-- Name: reported reported_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reported
    ADD CONSTRAINT reported_pkey PRIMARY KEY (nft_id);


--
-- Name: sale sale_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sale
    ADD CONSTRAINT sale_pkey PRIMARY KEY (nft_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (username);


--
-- Name: nft nft_author_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nft
    ADD CONSTRAINT nft_author_fkey FOREIGN KEY (author) REFERENCES public.users(username);


--
-- Name: nft nft_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nft
    ADD CONSTRAINT nft_owner_fkey FOREIGN KEY (owner) REFERENCES public.users(username);


--
-- Name: payment_methods payment_methods_username_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_username_fkey FOREIGN KEY (username) REFERENCES public.users(username);


--
-- Name: reported reported_nft_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reported
    ADD CONSTRAINT reported_nft_id_fkey FOREIGN KEY (nft_id) REFERENCES public.nft(id);


--
-- Name: sale sale_buyer_address_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sale
    ADD CONSTRAINT sale_buyer_address_fkey FOREIGN KEY (buyer_address) REFERENCES public.payment_methods(address);


--
-- Name: sale sale_nft_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sale
    ADD CONSTRAINT sale_nft_id_fkey FOREIGN KEY (nft_id) REFERENCES public.nft(id);


--
-- Name: sale sale_offer_maker_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sale
    ADD CONSTRAINT sale_offer_maker_fkey FOREIGN KEY (offer_maker) REFERENCES public.users(username);


--
-- Name: sale sale_seller_address_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sale
    ADD CONSTRAINT sale_seller_address_fkey FOREIGN KEY (seller_address) REFERENCES public.payment_methods(address);


--
-- PostgreSQL database dump complete
--

